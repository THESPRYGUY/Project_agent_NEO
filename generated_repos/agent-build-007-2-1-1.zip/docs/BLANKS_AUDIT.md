# Generated Repos Blanks Audit

Root: `generated_repos\agent-build-007-2-1-1`


## Per-Project Severity Summary

| Project | CRITICAL | HIGH | MED | LOW | Top Offenders (key_path -> file) |
| - | -: | -: | -: | -: | - |
| docs | 0 | 0 | 206 | 0 | (line) -> BLANKS_AUDIT.md, (line) -> BLANKS_AUDIT.md, (line) -> BLANKS_AUDIT.md |
| reports | 0 | 0 | 564 | 0 | (line) -> blanks_audit.json, (line) -> blanks_audit.json, (line) -> blanks_audit.json |

## Top 20 Findings

1. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
2. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
3. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
4. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
5. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
6. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
7. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
8. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
9. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
10. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
11. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
12. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
13. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
14. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
15. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
16. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
17. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
18. [MEDIUM] placeholder — `(line)` in `BLANKS_AUDIT.md` (docs)
19. [MEDIUM] placeholder — `(line)` in `BLANKS_REMEDIATION_PLAN.md` (docs)
20. [MEDIUM] placeholder — `(line)` in `BLANKS_REMEDIATION_PLAN.md` (docs)
