# Agent: Smoke Agent

## Role
- Title: IT Ops Lead
- Archetype: AIA-P

## Sector
- Sector: Computer Systems Design
- Region: CA
- Regulators: ISO_IEC_42001, NIST_AI_RMF, PIPEDA

## NAICS
- Code:  (level None)
- Title: 

## Directory Map & Narrative
See 01_README+Directory-Map_v2.json for canonical file listing.
